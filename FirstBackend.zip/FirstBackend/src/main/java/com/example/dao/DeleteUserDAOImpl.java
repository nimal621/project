package com.example.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.entity.UserEntity;
import com.example.model.User;

@Repository(value = "deleteUserDao")
public class DeleteUserDAOImpl  implements DeleteUserDAO{
	
	@Autowired
	EntityManager entityManager;
	
	@Override
	public Integer deleteUserDetails(Integer userid)
	{   
//		Query query = entityManager.createQuery("SELECT c FROM UserEntity c where c.userid=:empno");
//		query.setParameter("empno",userid);
//		List<UserEntity> userEntity=query.getResultList();
//		for(UserEntity ue:userEntity)
//		entityManager.remove(userEntity);
//		return userid;
		
		UserEntity userEntity=entityManager.find(UserEntity.class, userid);
		Integer userId=userEntity.getUserId();
		entityManager.remove(userEntity);
		return userId;
	}


}
