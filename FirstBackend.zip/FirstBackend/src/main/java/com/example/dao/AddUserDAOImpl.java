package com.example.dao;


import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.entity.UserEntity;
import com.example.model.User;



@Repository(value = "addUserDao")
public class AddUserDAOImpl implements AddUserDAO {
	
	@Autowired
	EntityManager entityManager;
    
	@Override
	public Integer addUserDetails(User user)
	{   System.out.println("hai");
		UserEntity userEntity = new UserEntity();
//		userEntity.setUserId(user.getUserid());
		userEntity.setEmpName(user.getEmpname());
		userEntity.setMobileNo(user.getMobileno());
		userEntity.setEmailId(user.getEmailid());
		userEntity.setEmpNo(user.getEmpno());
		System.out.println("hello");
		entityManager.persist(userEntity);
		System.out.println("hi");
		return userEntity.getUserId();
	}
}
