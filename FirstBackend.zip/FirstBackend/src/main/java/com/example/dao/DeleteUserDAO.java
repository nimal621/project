package com.example.dao;

import com.example.model.User;

public interface DeleteUserDAO {
	public Integer deleteUserDetails(Integer userid);

}
