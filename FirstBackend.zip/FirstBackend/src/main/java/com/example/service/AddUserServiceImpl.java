package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.AddUserDAO;
import com.example.model.User;





@Service(value = "AddUserService")
@Transactional
public class AddUserServiceImpl implements AddUserService {
	
	@Autowired
	private AddUserDAO addUserDao;
	
	@Override
	public Integer addUserDetails(User user) throws Exception
	{   System.out.println("hi");
		Integer userId=addUserDao.addUserDetails(user);
		return userId;
	}
	
	
	

}
