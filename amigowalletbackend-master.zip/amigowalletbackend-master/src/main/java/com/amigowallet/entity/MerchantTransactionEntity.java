package com.amigowallet.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import com.amigowallet.model.TransactionStatus;


@Entity
@Table(name="MERCHANT_TRANSACTION")
@GenericGenerator(name = "idGen", strategy = "increment")
public class MerchantTransactionEntity {

	@Id
	@Column(name="MERCHANT_TRANSACTION_ID")
	@GeneratedValue(generator="idGen")
	private Long merchantTransactionId;
	private Double amount;
	@CreationTimestamp
	@Column(name="TRANSACTION_DATE_TIME")
	private LocalDateTime transactionDateTime;
	private String remarks;
	private String info;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PAYMENT_TYPE_ID")
	private PaymentTypeEntity paymentTypeEntity;

	@Enumerated(EnumType.STRING)
	@Column(name="TRANSACTION_STATUS")
	private TransactionStatus transactionStatus;
	
	
	public Long getMerchantTransactionId() {
		return merchantTransactionId;
	}
	public void setMerchantTransactionId(Long merchantTransactionId) {
		this.merchantTransactionId = merchantTransactionId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public LocalDateTime getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDateTime transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public PaymentTypeEntity getPaymentTypeEntity() {
		return paymentTypeEntity;
	}
	public void setPaymentTypeEntity(PaymentTypeEntity paymentTypeEntity) {
		this.paymentTypeEntity = paymentTypeEntity;
	}
	public TransactionStatus getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(TransactionStatus transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	
	
}
