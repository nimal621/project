package com.amigowallet.api;

import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.amigowallet.model.Merchant;
import com.amigowallet.service.MerchantServiceService;

@CrossOrigin
@RestController
@RequestMapping(value="/paybill")
public class MerchantServiceAPI {

	@Autowired
	private Environment environment;
	
	@Autowired
	private MerchantServiceService merchantServiceService;
	
	static Logger logger=LogManager.getLogger(MerchantServiceAPI.class.getName());
	
	@GetMapping("/merchantList")
	public ResponseEntity<List<Merchant>> merchantList(){
		ResponseEntity<List<Merchant>> responseEntity=null;
		List<Merchant> list=new ArrayList<>();
		try{
			list=merchantServiceService.merchantList();
			responseEntity=new ResponseEntity<List<Merchant>>(list,HttpStatus.OK);
		}
		catch(Exception e){
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, environment.getProperty(e.getMessage()),e);
		}
		return responseEntity;
	}
	
	@RequestMapping(value="DeductMoney",method=RequestMethod.POST)
	public ResponseEntity<Integer> deductMoney(@RequestBody ArrayList<Object> data){
		ResponseEntity<Integer> responseEntity=null;
		try{
			Integer userId=(Integer) data.get(0);
			Double amount=(Double) data.get(1);
			String type=(String) data.get(2);
			logger.info("User deducting money from wallet:"+userId);
			Integer in=merchantServiceService.deductMoneyFromWallet(userId, amount,type);
			logger.info("User deducting money from wallet to pay merchant:"+userId);
			responseEntity=new ResponseEntity<Integer>(in,HttpStatus.OK);
		}
		catch(Exception e){
			throw new ResponseStatusException(HttpStatus.CONFLICT, environment.getProperty(e.getMessage()),e);
		}
		return responseEntity;
	}
	
	@RequestMapping(value="CreditMoney",method=RequestMethod.POST)
	public ResponseEntity<Long> creditMoney(@RequestBody ArrayList<Object> data){
		ResponseEntity<Long> responseEntity=null;
		try{
			Double amount=(Double) data.get(0);
			Integer id=(Integer) data.get(1);
			String edb=(String) data.get(2);
			logger.info("Paying to merchant "+id);
			Long merchantTransaction=merchantServiceService.creditMoney(amount,id,edb);
			responseEntity=new ResponseEntity<Long>(merchantTransaction,HttpStatus.OK);
		}
		catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()),e);
		}
		return responseEntity;
	}
	
	
}
