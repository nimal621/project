package com.amigowallet.api;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.amigowallet.model.User;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.service.UserLoginService;
import com.amigowallet.service.UserTransactionService;


@RestController
@CrossOrigin
@RequestMapping("wtwTransfer")

class WalletToWalletAPI {

	@Autowired
	private Environment environment;
	
	@Autowired
	private UserTransactionService userTransactionService;
	
	@Autowired
	private UserLoginService loginService;
	
	static Logger logger = LogManager.getLogger(WalletToWalletAPI.class.getName());
	
	@RequestMapping(value = "getUser", method = RequestMethod.POST)
	public ResponseEntity<User> getUser(@RequestBody String emailId){
		try{
			User user1=loginService.getUserbyEmailId(emailId);
			return new ResponseEntity<User>(user1,HttpStatus.OK);
	
		}
		catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,environment.getProperty(e.getMessage()));
		}
	}
	@PostMapping(value="transferMoney/{userId}/{amount}")
	public ResponseEntity<UserTransaction> transferMoneyToWallet(@RequestBody User receiver,@PathVariable("userId") Integer userId,@PathVariable("amount") Double amount ){
		try{
			UserTransaction userTransaction=userTransactionService.transferMoneyToWallet(amount, userId, receiver);
			return new ResponseEntity<UserTransaction>(userTransaction,HttpStatus.OK);
	}
		catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,environment.getProperty(e.getMessage()));
		}
	
}
}
