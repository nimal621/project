package com.amigowallet.api;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.amigowallet.model.UserObjectBankTransfer;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.service.TransferToBankService;
/**
 * This class has methods to handle requests related to transfering amount to bank from wallet.
 *
 * @author US_01
 * 
 */
@RestController
@CrossOrigin
@RequestMapping("TransferToBankAPI")
public class TransferToBankAPI {
	/**
	 * This attribute is used for getting property values from
	 * <b>configuration.properties</b> file
	 */
	
	@Autowired
	private Environment environment;

	@Autowired
	TransferToBankService transfertobankService;
	
	static Logger logger = LogManager.getLogger(TransferToBankAPI.class.getName());
	
	/**
	 * This method is used for deducting money from wallet<br>
	 * This method receives the amount and userId in POST request<br>
	 * It calls the payToBank method of TransferToBankService
	 * 
	 * @param String
	 * 
	 * @return ResponseEntity<UserTransaction> populated with 
	 * 					successMessage,
	 * 								if successfully deleted
	 * 					errorMessage,
	 * 								if any error occurs
	 */
	@RequestMapping(value = "debitFromWallet", method = RequestMethod.POST)
	public ResponseEntity<String> debitFromWallet(@RequestBody UserObjectBankTransfer userobj){
		String message=null;
		ResponseEntity<String> responseEntity=null;
		try{
		logger.info("USER TRYING TO DEBIT MONEY FROM WALLET AND DEBITED MONEY IS TRANSFERED TO BANK"+userobj.getUserId());
		/*
		 * The following code calls payToBank() method of TransferToBankService class
		 */
		UserTransaction usertransaction= transfertobankService.debitFromWallet(userobj.getUserId(),userobj.getAmount(),"D");
		logger.info("DEBITED MONEY FROM WALLET SUCCESSFULLY"+userobj.getUserId());
		/*
		 * The following code populates usertransaction with a success message
		 */
		message=environment.getProperty("PayToBankAPI.PAY_TO_BANK_SUCCESS");
		usertransaction.setMessage(message);
		responseEntity=new ResponseEntity<String>(message, HttpStatus.OK);	
		return responseEntity;
		}
		catch (Exception e) {	
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()),e);
		}
	}
	
	/**
	 * This method is used for crediting money to wallet when transaction fails(adding money to bank)<br>
	 * This method receives the amount and userId in POST request<br>
	 * It calls the creditToBank method of TransferToBankService
	 * 
	 * @param String
	 * 
	 * @return ResponseEntity<UserTransaction> populated with 
	 * 					successMessage,
	 * 								if successfully deleted
	 * 					errorMessage,
	 * 								if any error occurs
	 */
	@RequestMapping(value = "creditToWallet", method = RequestMethod.POST)
	public ResponseEntity<String> creditToBank(@RequestBody UserObjectBankTransfer userobj){
		String message=null;
		ResponseEntity<String> responseEntity=null;
		try{
		logger.info("CREDIT MONEY TO WALLET DUE TO ERROR WHEN TRANSFERING TO BANK"+userobj.getUserId());
		/*
		 * The following code calls payToBank() method of TransferToBankService class
		 */
		UserTransaction usertransaction= transfertobankService.creditToWallet(userobj.getUserId(),userobj.getAmount(),"C");
		logger.info("CREDITED MONEY TO WALLET SUCCESSFULLY"+userobj.getUserId());
		/*
		 * The following code populates message with a success message
		 */
		message=environment.getProperty("PayToBankAPI.PAY_TO_BANK_SUCCESS");
		usertransaction.setMessage(message);
		responseEntity=new ResponseEntity<String>(message, HttpStatus.OK);	
		return responseEntity;
		}
		catch (Exception e) {	
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()),e);
		}
	}
	
	
}
