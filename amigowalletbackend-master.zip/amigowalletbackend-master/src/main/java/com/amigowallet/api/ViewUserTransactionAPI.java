package com.amigowallet.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.amigowallet.model.UserTransaction;
import com.amigowallet.service.ViewUserTransactionService;

/**
 * This class has methods to handle requests related to viewUserTransaction
*/
@RestController
@CrossOrigin
@RequestMapping("viewTransactions")
public class ViewUserTransactionAPI {
	
	/*
	 * This attribute is used for getting property values from
	 * <b>configuration.properties</b> file
	 */
	@Autowired
	private Environment environment;
	
	@Autowired
	private ViewUserTransactionService viewuserTransactionService;
	
	/* This method gets the userid of the logged user and returns the list of 
	 * transactions if any otherwise throws the error message
	 */
	@RequestMapping(value = "/{userId}", method = RequestMethod.GET)
	public ResponseEntity<List<UserTransaction>> getAllTransactions(@PathVariable("userId") Integer userId)
	{  
		try{
		ResponseEntity<List<UserTransaction>> responseEntity=null;
		List<UserTransaction> userTransaction=new ArrayList<>();
		/* call to the getAllTransaction() in the service class */
		userTransaction=viewuserTransactionService.getAllTransactions(userId);
		responseEntity=new ResponseEntity<List<UserTransaction>>(userTransaction, HttpStatus.OK);
		return responseEntity;
		}
		/* If there is no transactions yet it is being caught here*/
		catch (Exception e)
		{
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, environment.getProperty(e.getMessage()));
		}
	}

	
}
