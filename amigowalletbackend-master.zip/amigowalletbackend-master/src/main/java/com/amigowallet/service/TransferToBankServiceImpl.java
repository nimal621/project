package com.amigowallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amigowallet.dao.TransferToBankDAO;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;

/**
 * This is a service class contains methods for business
 * logics related to  to transfer to bank from wallet.
 * 
 * @author ETA_JAVA
 *
 */
@Service(value = "transferToBankService")
@Transactional
public class TransferToBankServiceImpl implements TransferToBankService{
	@Autowired
	private TransferToBankDAO transferToBankDao;
	/**
	 * This method is used for debit money from wallet <br>
	 * 
	 * 
	 * @param UserId
	 *  @param Amount
	 */
	@Override
	public UserTransaction debitFromWallet(Integer userId, Double amount,String remark) throws Exception{
		UserTransaction userTransaction = new UserTransaction();
		/*
		 * A new userTransaction is created here and all the properties are populated
		 */
		userTransaction.setAmount(amount);
		userTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_PAY_TO_BANK);
		userTransaction.setPointsEarned(0);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		userTransaction.setRemarks(remark);
		/*
		 * here we are passing user id and usertransaction as an argument which gets us the user
		 * transaction details for that user id from the data base table and returns
		 * the usertransaction for that user id
		 */
		userTransaction=transferToBankDao.debitFromWallet(userTransaction,userId);
		return userTransaction;
		
	}
	/**
	 * This method is used for crediting money to wallet when transaction fails in bank<br>
	 * 
	 * 
	 * @param UserId
	 *  @param Amount
	 */
	@Override
	public UserTransaction creditToWallet(Integer userId, Double amount,String remark) throws Exception{
		UserTransaction userTransaction = new UserTransaction();
		/*
		 * A new userTransaction is created here and all the properties are populated
		 */
		userTransaction.setAmount(amount);
		userTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_ADDED_DUE_TO_TRANSACTION_FAIL_IN_BANK);
		userTransaction.setPointsEarned(0);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		userTransaction.setRemarks(remark);
		/*
		 * here we are passing user id and usertransaction as an argument which gets us the user
		 * transaction details for that user id from the data base table and returns
		 * the usertransaction for that user id
		 */
		userTransaction=transferToBankDao.creditToWallet(userTransaction,userId);
		return userTransaction;
	}
	
}
