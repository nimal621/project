package com.amigowallet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amigowallet.dao.MerchantServiceDAO;
import com.amigowallet.model.Merchant;
import com.amigowallet.model.MerchantTransaction;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;

@Service(value="MerchantServiceService")
@Transactional
public class MerchantServiceServiceImpl implements MerchantServiceService{
	
	@Autowired
	private MerchantServiceDAO merchantServiceDAO;
	
	@Override
	public List<Merchant> merchantList() throws Exception {
		// TODO Auto-generated method stub
		return merchantServiceDAO.merchantList();
	}

	@Override
	public Integer deductMoneyFromWallet(Integer userId, Double amount,String type) throws Exception {
		// TODO Auto-generated method stub
		UserTransaction userTransaction = new UserTransaction();
		int rewardpoints;
		if(amount>0){
			rewardpoints=(int) (amount/10);
		}
		else{
			rewardpoints=0;
		}
		userTransaction.setAmount(amount);
		userTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_MERCHANTPAYMENT_DEBIT	+type);
		userTransaction.setPointsEarned(rewardpoints);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_NO.charAt(0));
		userTransaction = merchantServiceDAO.deductMoney(userTransaction, userId,amount,type);
		return rewardpoints;
	}

	@Override
	public Long creditMoney(Double amount, Integer merchantId,String edb) throws Exception {
		// TODO Auto-generated method stub
		MerchantTransaction type = new MerchantTransaction();
		
		type.setAmount(amount);
		type.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_MERCHANTPAYMENT_DEBIT+edb.toString());
		type = merchantServiceDAO.creditMoney(type, merchantId);
		return type.getMerchantTransactionId();
	}



	

}
