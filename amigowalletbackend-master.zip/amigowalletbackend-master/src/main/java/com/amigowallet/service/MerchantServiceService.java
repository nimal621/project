package com.amigowallet.service;

import java.util.List;

import com.amigowallet.model.Merchant;

public interface MerchantServiceService {
	public List<Merchant> merchantList() throws Exception;
	
	public Integer deductMoneyFromWallet(Integer userId,Double amount,String type) throws Exception;

	public Long creditMoney(Double amount,Integer merchantId,String edb) throws Exception;
}
