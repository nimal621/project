package com.amigowallet.service;

import com.amigowallet.model.UserTransaction;
/**
 * This is a service interface contains methods for business
 * logics related to transfer to bank from wallet.
 * 
 * @author US_01
 * 
 */
public interface TransferToBankService {
	/**
	 * This method is used for debit money from wallet <br>
	 * 
	 * 
	 * @param UserId
	 *  @param Amount
	 */
	public UserTransaction debitFromWallet(Integer userId,Double amount,String remark) throws Exception;
	/**
	 * This method is used for crediting money to wallet when transaction fails in bank<br>
	 * 
	 * 
	 * @param UserId
	 *  @param Amount
	 */
	public UserTransaction creditToWallet(Integer userId,Double amount,String remark) throws Exception;

}
