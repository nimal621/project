package com.amigowallet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amigowallet.dao.ViewUserTransactionDAO;
import com.amigowallet.model.UserTransaction;
/*
 * This is a service interface contains methods for business
 * logics related to User Transactions 
 */
@Service(value = "viewUserTransactionService")
@Transactional
public class ViewUserTransactionServiceImpl implements ViewUserTransactionService {
	
	@Autowired
	private ViewUserTransactionDAO viewUserTransactionDAO;
	
	  /* This function gets the list of user Transactions */
	@Override
	public List<UserTransaction> getAllTransactions(Integer userId) throws Exception
	{
		List<UserTransaction> userTransactionList = viewUserTransactionDAO.getAllTransactions(userId);
		/*If there is no transaction yet it is being handled */
		if(userTransactionList==null || userTransactionList.size()==0)
			throw new Exception("ViewUserTransactionService.NO_TRANSACTION");
		return userTransactionList;
		
	}


}
