package com.amigowallet.service;

import java.util.List;

import com.amigowallet.model.UserTransaction;
/*
 * This is a service interface contains methods for business
 * logics related to User Transactions 
 */
public interface ViewUserTransactionService {
   /* This function gets the list of user Transactions */  
	public List<UserTransaction> getAllTransactions(Integer userId) throws Exception;
	
}
