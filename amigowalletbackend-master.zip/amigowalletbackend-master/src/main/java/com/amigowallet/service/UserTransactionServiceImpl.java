package com.amigowallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amigowallet.dao.UserTransactionDAO;
import com.amigowallet.model.User;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;

/**
 * This is a service class which includes methods for performing different transactions 
 * like loadMoneyFromDebitCard, loadMoneyFromNetBanking
 * 
 * @author ETA_JAVA
 *
 */
@Service("userTransactionService")
@Transactional
public class UserTransactionServiceImpl implements UserTransactionService {

	@Autowired
	private UserTransactionDAO userTransactionDAO;
	
	/**
	 * This method id used to do load money i.e. credit money to the amigo wallet which is called after 
	 * debiting the money from bank account through debit card banking
	 *
	 * @param amount
	 * @param userId
	 * @param remarks
	 * 
	 * @return userTransaction
	 */
	@Override
	public UserTransaction loadMoneyFromDebitCard(Double amount, Integer userId, String remarks)
	{
		
		UserTransaction userTransaction = new UserTransaction();
		
		/*
		 * A new userTransaction is created here and all the properties are populated
		 */
		userTransaction.setAmount(amount);
		userTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_ADDED_FROM_BANK_TO_EWALLET_USING_DEBIT_CARD);
		userTransaction.setPointsEarned(0);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		userTransaction.setRemarks(remarks);
		
		/*
		 * DAO method for loading money to the wallet is called here
		 */
		userTransaction = userTransactionDAO.loadMoney(userTransaction,userId);
		
		/*
		 * The userTransaction bean is returned here
		 */
		return userTransaction;
	}
	

	/**
	 * This method id used to do load money i.e. credit money to the amigo wallet which is called after 
	 * debiting the money from bank account through net banking
	 * 
	 * @param amount
	 * @param userId
	 * @param remarks
	 * 
	 * @return userTransaction
	 */
	@Override
	public UserTransaction loadMoneyFromNetBanking(Double amount, Integer userId, String remarks) {
		
		UserTransaction userTransaction = new UserTransaction();
		
		/*
		 * A new userTransaction is created here and all the properties are populated
		 */
		userTransaction.setAmount(amount);
		userTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_ADDED_FROM_BANK_TO_EWALLET_USING_NET_BANKING);
		userTransaction.setPointsEarned(0);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		userTransaction.setRemarks(remarks);
		
		/*
		 * DAO method for loading money to the wallet is called here
		 */
		userTransaction = userTransactionDAO.loadMoney(userTransaction,userId);
		
		/*
		 * The userTransaction bean is returned here
		 */
		return userTransaction;		
	}


	@Override
	public UserTransaction transferMoneyToWallet(Double amount, Integer senderId, User receiver) {
		// TODO Auto-generated method stub
		UserTransaction debitTransaction=new UserTransaction();
		debitTransaction.setAmount(amount);
		debitTransaction.setPointsEarned(0);
		debitTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		debitTransaction.setRemarks("D");
		debitTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_WALLET_DEBIT+receiver.getEmailId());
		
		UserTransaction creditTransaction=new UserTransaction();
		creditTransaction.setAmount(amount);
		creditTransaction.setInfo("");
		creditTransaction.setPointsEarned(0);
		creditTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		creditTransaction.setRemarks("C");
		
		debitTransaction=userTransactionDAO.transferMoneyToWallet(debitTransaction, creditTransaction,senderId,receiver.getUserId());
		
		return debitTransaction;
	}
	
}
