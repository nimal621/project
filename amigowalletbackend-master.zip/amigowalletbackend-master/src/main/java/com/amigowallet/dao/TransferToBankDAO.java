package com.amigowallet.dao;

import com.amigowallet.model.UserTransaction;
/** 
 * This is DAO interface contains the methods responsible for interacting with
 * the database with respect to debiting amount from wallet and crediting if bank transaction fails and  details like
 * <BR>
 * -debitFromWallet<br>
 * -creditToWallet<br>
 * 
 * 
 * @author US_01
 *
 */
public interface TransferToBankDAO {
	/**
	 * This method receives userTransaction object and UserId as  arguments 
	 * is used to debit money from wallet from the database.
	 * 
	 *  
	 * @param userTransaction
	 * @param UserId
	 * 
	 */
	public UserTransaction debitFromWallet(UserTransaction userTransaction, Integer userId) throws Exception;
	/**
	 * This method receives userTransaction object and UserId as  arguments 
	 * is used to credit money to wallet when transaction fails in bank from the database.
	 * 
	 * @param userTransaction
	 * @param UserId
	 */
	public UserTransaction creditToWallet(UserTransaction userTransaction, Integer userId) throws Exception;

}
