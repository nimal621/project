package com.amigowallet.dao;

import java.util.List;

import com.amigowallet.model.UserTransaction;
/*
 * This is DAO interface contains the methods responsible for interacting with
 * the database for collecting user transactions
 */
public interface ViewUserTransactionDAO {

	public List<UserTransaction> getAllTransactions(Integer userId);
	
}
