package com.amigowallet.dao;

import java.util.List;

import com.amigowallet.model.Merchant;
import com.amigowallet.model.MerchantTransaction;
import com.amigowallet.model.UserTransaction;

public interface MerchantServiceDAO {

	public List<Merchant> merchantList() throws Exception;
	
	public UserTransaction deductMoney(UserTransaction userTransaction, Integer userId,Double amount,String type) throws Exception;

	public MerchantTransaction creditMoney(MerchantTransaction merchantTransaction,  Integer merchantId) throws Exception;
}
