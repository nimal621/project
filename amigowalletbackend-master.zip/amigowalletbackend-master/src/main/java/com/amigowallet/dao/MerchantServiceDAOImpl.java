package com.amigowallet.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amigowallet.model.Merchant;
import com.amigowallet.model.MerchantServiceType;
import com.amigowallet.model.MerchantStatus;
import com.amigowallet.model.MerchantTransaction;
import com.amigowallet.model.PaymentType;
import com.amigowallet.model.TransactionStatus;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;
import com.amigowallet.entity.MerchantEntity;
import com.amigowallet.entity.MerchantServiceTypeEntity;
import com.amigowallet.entity.MerchantTransactionEntity;
import com.amigowallet.entity.PaymentTypeEntity;
import com.amigowallet.entity.UserEntity;
import com.amigowallet.entity.UserTransactionEntity;

@Repository(value="merchantServiceDAO")
public class MerchantServiceDAOImpl implements MerchantServiceDAO{
	
	@Autowired
	EntityManager entityManager;

	@Override
	public List<Merchant> merchantList() throws Exception {
		// TODO Auto-generated method stub
		List<Merchant> list=new ArrayList<>();
		Query query=entityManager.createQuery("select m from MerchantEntity m");
		List<MerchantEntity> mentity = query.getResultList();
		for(MerchantEntity m:mentity){
			Merchant merchant=new Merchant();
			List<MerchantServiceType> mst=new ArrayList<>();
			if(m.getMerchantStatus().equals(MerchantStatus.ACTIVE)){
				merchant.setName(m.getName());
				merchant.setMerchantId(m.getMerchantId());
				merchant.setEmailId(m.getEmailId());
				List<MerchantServiceTypeEntity> msTypeEntities=m.getMerchantServiceTypes();
				for(MerchantServiceTypeEntity mste:msTypeEntities){
					MerchantServiceType merchantServiceType=new MerchantServiceType();
					merchantServiceType.setServiceId(mste.getServiceId());
					merchantServiceType.setServiceType(mste.getServiceType());
					mst.add(merchantServiceType);
				}
			merchant.setMerchantServiceTypes(mst);
			list.add(merchant);
			}
		}
		return list;
	}

	@Override
	public UserTransaction deductMoney(UserTransaction userTransaction, Integer userId,Double amount,String type) {
		UserEntity userEntity = entityManager.find(UserEntity.class, userId);
		List<UserTransactionEntity> transactionEntities = userEntity.getUserTransactionEntities();
		
		UserTransactionEntity transactionEntity = new UserTransactionEntity();
		transactionEntity.setAmount(userTransaction.getAmount());
		transactionEntity.setIsRedeemed(userTransaction.getIsRedeemed());
		transactionEntity.setInfo(userTransaction.getInfo());	

		Query query = entityManager.createQuery(
				"from PaymentTypeEntity where paymentFrom = :paymentFrom and paymentTo = :paymentTo and paymentType = :paymentType");
		query.setParameter("paymentFrom", AmigoWalletConstants.PAYMENT_FROM_WALLET.charAt(0));
		query.setParameter("paymentTo", AmigoWalletConstants.PAYMENT_TO_MERCHANT.charAt(0));
		query.setParameter("paymentType", AmigoWalletConstants.PAYMENT_TYPE_DEBIT.charAt(0));
		PaymentTypeEntity paymentTypeEntity = (PaymentTypeEntity) query.getSingleResult();
		
		transactionEntity.setPaymentTypeEntity(paymentTypeEntity);
		transactionEntity.setPointsEarned(userTransaction.getPointsEarned());
		transactionEntity.setRemarks(userTransaction.getRemarks());

		transactionEntity.setTransactionStatus(TransactionStatus.SUCCESS);

		transactionEntities.add(transactionEntity);
		entityManager.persist(transactionEntity);
		userEntity.setUserTransactionEntities(transactionEntities);
		
		entityManager.persist(userEntity);
		userTransaction.setUserTransactionId(transactionEntity.getUserTransactionId());
		
		if (paymentTypeEntity != null) {
			
			PaymentType paymentType = new PaymentType();
			paymentType.setPaymentFrom(paymentTypeEntity.getPaymentFrom());
			paymentType.setPaymentTo(paymentTypeEntity.getPaymentTo());
			paymentType.setPaymentType(paymentTypeEntity.getPaymentType());
			paymentType.setPaymentTypeId(paymentTypeEntity.getPaymentTypeId());

			userTransaction.setPaymentType(paymentType);
		}
		
		userTransaction.setTransactionStatus(transactionEntity.getTransactionStatus());
		return userTransaction;
	}

	@Override
	public MerchantTransaction creditMoney(MerchantTransaction merchantTransaction, Integer merchantId) throws Exception {
		Query query = entityManager.createQuery("select m from MerchantEntity m where m.merchantId=?1");
		query.setParameter(1, merchantId);
		MerchantEntity entity=(MerchantEntity) query.getSingleResult();
		
		List<MerchantTransactionEntity> merchantTransactionEntity= entity.getMerchantTransactionEntities();
		MerchantTransactionEntity entity2=new MerchantTransactionEntity();
		entity2.setAmount(merchantTransaction.getAmount());
		entity2.setInfo(merchantTransaction.getInfo());
		entity2.setRemarks(merchantTransaction.getRemarks());
		entity2.setTransactionStatus(TransactionStatus.SUCCESS);
		
		Query query1 = entityManager.createQuery(
				"from PaymentTypeEntity where paymentFrom = :paymentFrom and paymentTo = :paymentTo and paymentType = :paymentType");
		query1.setParameter("paymentFrom", AmigoWalletConstants.PAYMENT_FROM_WALLET.charAt(0));
		query1.setParameter("paymentTo", AmigoWalletConstants.PAYMENT_TO_MERCHANT.charAt(0));
		query1.setParameter("paymentType", AmigoWalletConstants.PAYMENT_TYPE_CREDIT.charAt(0));
		PaymentTypeEntity paymentTypeEntity = (PaymentTypeEntity) query1.getSingleResult();
		entity2.setPaymentTypeEntity(paymentTypeEntity);
		merchantTransactionEntity.add(entity2);
		entityManager.persist(entity2);
		entity.setMerchantTransactionEntities(merchantTransactionEntity);
		entityManager.persist(entity);
		merchantTransaction.setMerchantTransactionId(entity2.getMerchantTransactionId());
		if (paymentTypeEntity != null) {
			PaymentType paymentType = new PaymentType();
			paymentType.setPaymentFrom(paymentTypeEntity.getPaymentFrom());
			paymentType.setPaymentTo(paymentTypeEntity.getPaymentTo());
			paymentType.setPaymentType(paymentTypeEntity.getPaymentType());
			paymentType.setPaymentTypeId(paymentTypeEntity.getPaymentTypeId());
			merchantTransaction.setPaymentType(paymentType);
		}
		merchantTransaction.setTransactionStatus(entity2.getTransactionStatus());
		return merchantTransaction;
		
	}

	
	
	
	}
	 
	 

