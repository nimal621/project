package com.amigowallet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.amigowallet.entity.PaymentTypeEntity;
import com.amigowallet.entity.UserEntity;
import com.amigowallet.entity.UserTransactionEntity;
import com.amigowallet.model.PaymentType;
import com.amigowallet.model.TransactionStatus;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;

/**
 * This is a DAO class having method to perform CRUD operations on user and transactions
 * on performing different transactions like loadMoney, debitMoney etc.
 * 
 * @author ETA_JAVA
 * 
 */
@Repository("userTransactionDAO")
public class UserTransactionDAOImpl implements UserTransactionDAO {
	
	/** This is a spring auto-wired attribute used to create data base sessions */
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private Environment environment;
	
	/**
	 * This method is used for adding the transaction for given userId for loading money to amigo wallet.
	 * 
	 * @param userTransaction
	 * @param userId
	 * 
	 * @return userTransaction
	 */
	@Override
	public UserTransaction loadMoney(UserTransaction userTransaction, Integer userId) {
		
		UserEntity userEntity = entityManager.find(UserEntity.class, userId);
		List<UserTransactionEntity> transactionEntities = userEntity.getUserTransactionEntities();
		
		UserTransactionEntity transactionEntity = new UserTransactionEntity();
		transactionEntity.setAmount(userTransaction.getAmount());
		transactionEntity.setIsRedeemed(userTransaction.getIsRedeemed());
		transactionEntity.setInfo(userTransaction.getInfo());	
		
		/*
		 * The following code is to set the paymentTypeEntity to transactionEntity
		 */

		Query query = entityManager.createQuery(
				"from PaymentTypeEntity where paymentFrom = :paymentFrom and paymentTo = :paymentTo and paymentType = :paymentType");
		query.setParameter("paymentFrom", AmigoWalletConstants.PAYMENT_FROM_BANK.charAt(0));
		query.setParameter("paymentTo", AmigoWalletConstants.PAYMENT_TO_WALLET.charAt(0));
		query.setParameter("paymentType", AmigoWalletConstants.PAYMENT_TYPE_CREDIT.charAt(0));
		PaymentTypeEntity paymentTypeEntity = (PaymentTypeEntity) query.getSingleResult();
		
		transactionEntity.setPaymentTypeEntity(paymentTypeEntity);
		transactionEntity.setPointsEarned(userTransaction.getPointsEarned());
		transactionEntity.setRemarks(userTransaction.getRemarks());
		
		/*
		 * The following code is to set the StatusEntity to transactionEntity
		 */

		transactionEntity.setTransactionStatus(TransactionStatus.SUCCESS);

		transactionEntities.add(transactionEntity);
		entityManager.persist(transactionEntity);
		userEntity.setUserTransactionEntities(transactionEntities);
		
		/*
		 * The userEntity is saved to the database
		 */
		entityManager.persist(userEntity);
		userTransaction.setUserTransactionId(transactionEntity.getUserTransactionId());
		
		/*
		 * The following code is to set the paymenType model object to transaction model object
		 */
		if (paymentTypeEntity != null) {
			
			PaymentType paymentType = new PaymentType();
			paymentType.setPaymentFrom(paymentTypeEntity.getPaymentFrom());
			paymentType.setPaymentTo(paymentTypeEntity.getPaymentTo());
			paymentType.setPaymentType(paymentTypeEntity.getPaymentType());
			paymentType.setPaymentTypeId(paymentTypeEntity.getPaymentTypeId());

			userTransaction.setPaymentType(paymentType);
		}
		
		userTransaction.setTransactionStatus(transactionEntity.getTransactionStatus());
		return userTransaction;
	}
	@Override
	public UserTransaction transferMoneyToWallet(UserTransaction debitTransaction,UserTransaction creditTransaction,Integer senderId,Integer receiverId){
		UserEntity sender=entityManager.find(UserEntity.class,senderId);
		List<UserTransactionEntity> transactionEntities=sender.getUserTransactionEntities();
		UserTransactionEntity debitTransactionEntity=new UserTransactionEntity();
		debitTransactionEntity.setAmount(debitTransaction.getAmount());
		debitTransactionEntity.setIsRedeemed(debitTransaction.getIsRedeemed());
		
		debitTransactionEntity.setInfo(debitTransaction.getInfo());
		
		Query query=entityManager.createQuery("from PaymentTypeEntity where paymentFrom = :paymentFrom and paymentTo = :paymentTo and paymentType = :paymentType");
		query.setParameter("paymentFrom", AmigoWalletConstants.PAYMENT_FROM_WALLET.charAt(0));
		query.setParameter("paymentTo", AmigoWalletConstants.PAYMENT_TO_WALLET.charAt(0));
		query.setParameter("paymentType", AmigoWalletConstants.PAYMENT_TYPE_DEBIT.charAt(0));
		PaymentTypeEntity paymentTypeEntity = (PaymentTypeEntity) query.getSingleResult();
		
		debitTransactionEntity.setPaymentTypeEntity(paymentTypeEntity);
		debitTransactionEntity.setPointsEarned(debitTransaction.getPointsEarned());
		debitTransactionEntity.setRemarks(debitTransaction.getRemarks());
		
		/*
		 * The following code is to set the StatusEntity to transactionEntity
		 */

		debitTransactionEntity.setTransactionStatus(TransactionStatus.SUCCESS);
		transactionEntities.add(debitTransactionEntity);
		entityManager.persist(debitTransactionEntity);
		sender.setUserTransactionEntities(transactionEntities);
		entityManager.persist(sender);
		debitTransaction.setUserTransactionId(debitTransactionEntity.getUserTransactionId());
		if(paymentTypeEntity!=null){
			PaymentType paymentType=new PaymentType();
			paymentType.setPaymentType(paymentTypeEntity.getPaymentType());
			paymentType.setPaymentFrom(paymentTypeEntity.getPaymentFrom());
			paymentType.setPaymentTo(paymentTypeEntity.getPaymentTo());
			paymentType.setPaymentTypeId(paymentTypeEntity.getPaymentTypeId());
			debitTransaction.setPaymentType(paymentType);
		}
			
		debitTransaction.setTransactionStatus(debitTransactionEntity.getTransactionStatus());
		debitTransaction.setMessage(environment.getProperty("WalletAPI.SUCCESSFUL_TRANSACTION"));
		
		
		UserEntity receiver=entityManager.find(UserEntity.class, receiverId);
		debitTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_WALLET_DEBIT+ receiver.getEmailId());
		List<UserTransactionEntity> transactionEnt1=receiver.getUserTransactionEntities();
		UserTransactionEntity creditTransactionEntity=new UserTransactionEntity();
		creditTransactionEntity.setAmount(creditTransaction.getAmount());
		creditTransactionEntity.setIsRedeemed(creditTransaction.getIsRedeemed());
		creditTransactionEntity.setInfo(creditTransaction.getInfo());
		Query query1=entityManager.createQuery("from PaymentTypeEntity where paymentFrom = :paymentFrom and paymentTo = :paymentTo and paymentType = :paymentType");
		query1.setParameter("paymentFrom", AmigoWalletConstants.PAYMENT_FROM_WALLET.charAt(0));
		query1.setParameter("paymentTo", AmigoWalletConstants.PAYMENT_TO_WALLET.charAt(0));
		query1.setParameter("paymentType", AmigoWalletConstants.PAYMENT_TYPE_CREDIT.charAt(0));
		PaymentTypeEntity paymentTypeEntity1 = (PaymentTypeEntity) query1.getSingleResult();
		creditTransactionEntity.setPaymentTypeEntity(paymentTypeEntity1);
		creditTransactionEntity.setPointsEarned(creditTransaction.getPointsEarned());
		creditTransactionEntity.setRemarks(creditTransaction.getRemarks());
		creditTransactionEntity.setTransactionStatus(TransactionStatus.SUCCESS);
		transactionEnt1.add(creditTransactionEntity);
		entityManager.persist(creditTransactionEntity);
		receiver.setUserTransactionEntities(transactionEnt1);
		entityManager.persist(receiver);
		creditTransaction.setUserTransactionId(creditTransactionEntity.getUserTransactionId());
		if(paymentTypeEntity1!=null){
			PaymentType paymentType1=new PaymentType();
			paymentType1.setPaymentType(paymentTypeEntity1.getPaymentType());
			paymentType1.setPaymentFrom(paymentTypeEntity1.getPaymentFrom());
			paymentType1.setPaymentTo(paymentTypeEntity1.getPaymentTo());
			paymentType1.setPaymentTypeId(paymentTypeEntity1.getPaymentTypeId());
			creditTransaction.setPaymentType(paymentType1);
		}
			
		creditTransaction.setTransactionStatus(creditTransactionEntity.getTransactionStatus());
		creditTransaction.setMessage(environment.getProperty("WalletAPI.SUCCESSFUL_TRANSACTION"));
		creditTransaction.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_WALLET_CREDIT+sender.getEmailId());
		creditTransactionEntity.setInfo(creditTransaction.getInfo());
		entityManager.persist(creditTransactionEntity);
		return debitTransaction;
		
	}
}
