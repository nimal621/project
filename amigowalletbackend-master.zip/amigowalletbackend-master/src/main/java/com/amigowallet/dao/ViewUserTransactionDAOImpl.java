package com.amigowallet.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amigowallet.entity.UserEntity;
import com.amigowallet.entity.UserTransactionEntity;
import com.amigowallet.model.PaymentType;
import com.amigowallet.model.UserTransaction;

/*
 * This is DAO interface contains the methods responsible for interacting with
 * the database for collecting user transactions
 */
@Repository(value="viewUserTransactionDAO")
public class ViewUserTransactionDAOImpl implements ViewUserTransactionDAO{

	@Autowired
	EntityManager entityManager;
	
	/* Interacts with database for the given userId and returns the given user transaction list*/
	@Override
	public List<UserTransaction> getAllTransactions(Integer userId)
	{
		UserEntity userEntity=entityManager.find(UserEntity.class, userId);
		List<UserTransactionEntity> userTransactionEntityList=userEntity.getUserTransactionEntities();
		List<UserTransaction> userTransactionList=new ArrayList<>();
		for(UserTransactionEntity userTransactionEntity:userTransactionEntityList)
		{
			UserTransaction userTransaction=new UserTransaction();
			userTransaction.setAmount(userTransactionEntity.getAmount());
			userTransaction.setInfo(userTransactionEntity.getInfo());
			userTransaction.setUserTransactionId(userTransactionEntity.getUserTransactionId());
			userTransaction.setTransactionDateTime(userTransactionEntity.getTransactionDateTime());
			userTransaction.setTransactionStatus(userTransactionEntity.getTransactionStatus());
			userTransaction.setIsRedeemed(userTransactionEntity.getIsRedeemed());
			userTransaction.setRemarks(userTransactionEntity.getRemarks());
			userTransaction.setPointsEarned(userTransactionEntity.getPointsEarned());
			
			PaymentType paymentType=new PaymentType();
			if(paymentType!=null)
			{
			  paymentType.setPaymentType(userTransactionEntity.getPaymentTypeEntity().getPaymentType());
			  paymentType.setPaymentFrom(userTransactionEntity.getPaymentTypeEntity().getPaymentFrom());
			  paymentType.setPaymentTo(userTransactionEntity.getPaymentTypeEntity().getPaymentTo());
			  paymentType.setPaymentTypeId(userTransactionEntity.getPaymentTypeEntity().getPaymentTypeId());
			  userTransaction.setPaymentType(paymentType);
			  
			  
			}
			userTransactionList.add(0,userTransaction);
		}
		
		return userTransactionList;
	}

}
