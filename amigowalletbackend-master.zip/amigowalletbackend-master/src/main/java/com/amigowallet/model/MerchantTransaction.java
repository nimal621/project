package com.amigowallet.model;

import java.time.LocalDateTime;



public class MerchantTransaction {

	private Long merchantTransactionId;
	private Double amount;
	
	private LocalDateTime transactionDateTime;
	private String remarks;
	private String info;
	private PaymentType paymentType;
	private TransactionStatus transactionStatus;
	public PaymentType getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	public TransactionStatus getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(TransactionStatus transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	
	public Long getMerchantTransactionId() {
		return merchantTransactionId;
	}
	public void setMerchantTransactionId(Long merchantTransactionId) {
		this.merchantTransactionId = merchantTransactionId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public LocalDateTime getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDateTime transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}

}
