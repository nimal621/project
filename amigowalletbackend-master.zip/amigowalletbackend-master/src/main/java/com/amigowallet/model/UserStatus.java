package com.amigowallet.model;

public enum UserStatus {
	ACTIVE,
	INACTIVE
}
