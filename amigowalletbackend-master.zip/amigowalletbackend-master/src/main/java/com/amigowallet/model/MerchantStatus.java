package com.amigowallet.model;

public enum MerchantStatus {
	ACTIVE,
	INACTIVE
}
