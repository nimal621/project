package com.amigowallet.model;

public enum TransactionStatus {
	SUCCESS,
	FAILURE,
	PENDING
}
