package com.amigowallet.model;

public enum CardStatus {
	ACTIVE,
	INACTIVE
}
