package com.amigowallet.model;
import java.time.LocalDateTime;
import java.util.List;


public class Merchant {
	private Integer merchantId;
	private String emailId;
	private String name;
	private String password;
	private String mobileNumber;
	private MerchantStatus merchantStatus;
	private LocalDateTime createdTimestamp;
	private LocalDateTime modifiedTimestamp;
	private List<MerchantServiceType> merchantServiceTypes;
	private List<MerchantTransaction> merchantTransaction;
	
	public List<MerchantTransaction> getMerchantTransaction() {
		return merchantTransaction;
	}
	public void setMerchantTransaction(List<MerchantTransaction> merchantTransaction) {
		this.merchantTransaction = merchantTransaction;
	}
	public Integer getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public MerchantStatus getMerchantStatus() {
		return merchantStatus;
	}
	public void setMerchantStatus(MerchantStatus merchantStatus) {
		this.merchantStatus = merchantStatus;
	}
	public LocalDateTime getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(LocalDateTime createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public LocalDateTime getModifiedTimestamp() {
		return modifiedTimestamp;
	}
	public void setModifiedTimestamp(LocalDateTime modifiedTimestamp) {
		this.modifiedTimestamp = modifiedTimestamp;
	}
	public List<MerchantServiceType> getMerchantServiceTypes() {
		return merchantServiceTypes;
	}
	public void setMerchantServiceTypes(
			List<MerchantServiceType> merchantServiceTypes) {
		this.merchantServiceTypes = merchantServiceTypes;
	}

	
}
