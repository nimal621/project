package com.amigowallet.dao.test;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.amigowallet.dao.TransferToBankDAO;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@Rollback(true)
public class TransferToBankDAOTest {
	/**
	 * This attribute is used in all the test case methods to invoke the methods
	 * of {@link transferToBankDao}
	 * 
	 * The annotation @Autowired helps to get the object from Spring container,
	 * we do not have to explicitly create the object to use it.
	 */
	@Autowired
	private TransferToBankDAO transferToBankDAO;
	@Test
	public void debitFromWalletTest() throws Exception {
		UserTransaction userTransaction = new UserTransaction();
		userTransaction.setAmount(500.00);
		userTransaction
				.setInfo(AmigoWalletConstants.TRANSACTION_INFO_PAY_TO_BANK);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		userTransaction.setPointsEarned(5);
		userTransaction.setRemarks("D");
		userTransaction.setTransactionDateTime(LocalDateTime.now());
		transferToBankDAO.debitFromWallet(userTransaction, 12121);
		Assert.assertTrue(true);
	}
	@Test
	public void creditToWalletTest() throws Exception {
		UserTransaction userTransaction = new UserTransaction();
		userTransaction.setAmount(500.00);
		userTransaction
				.setInfo(AmigoWalletConstants.TRANSACTION_INFO_MONEY_ADDED_DUE_TO_TRANSACTION_FAIL_IN_BANK);
		userTransaction.setIsRedeemed(AmigoWalletConstants.REWARD_POINTS_REDEEMED_YES.charAt(0));
		userTransaction.setPointsEarned(5);
		userTransaction.setRemarks("C");
		userTransaction.setTransactionDateTime(LocalDateTime.now());
		transferToBankDAO.creditToWallet(userTransaction, 12121);
		Assert.assertTrue(true);
	}
}
