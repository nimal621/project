package com.amigowallet.dao.test;

import java.time.LocalDateTime;
import java.util.List;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import com.amigowallet.dao.MerchantServiceDAO;
import com.amigowallet.model.Merchant;
import com.amigowallet.model.MerchantTransaction;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@Rollback(true)
public class MerchantServiceDAOTest {
	
	@Autowired
	private  MerchantServiceDAO customerToMerchantPaymentDAO;
	
	@Rule
	public ExpectedException ee=ExpectedException.none();

	@Test
	public void merchantDetailsValid() throws Exception
	{
	List<Merchant> merchantList=customerToMerchantPaymentDAO.merchantList();
	Assert.assertTrue(merchantList.size()>0);
	}
		
	@Test
	public void debitMoneyFromWalletValid() throws Exception
	{
		Double amount=500.0;
		Double rewardPoints = amount/10;
		UserTransaction userDebitTransaction=new UserTransaction();
		userDebitTransaction.setAmount(amount);
		userDebitTransaction.setTransactionDateTime(LocalDateTime.now());
		userDebitTransaction.setIsRedeemed((AmigoWalletConstants.REWARD_POINTS_REDEEMED_NO).charAt(0));
		userDebitTransaction.setInfo
		(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_MERCHANTPAYMENT_DEBIT + "cescorp@infy.com");
		userDebitTransaction.setRemarks(AmigoWalletConstants.PAYMENT_TYPE_DEBIT);
		userDebitTransaction.setPointsEarned(rewardPoints.intValue());
		customerToMerchantPaymentDAO.deductMoney(userDebitTransaction, 12121,amount,AmigoWalletConstants.PAYMENT_TYPE_DEBIT);
		Assert.assertTrue(true);
	}


	@Test
	public void creditMoneyToMerchantValid() throws Exception
	{
		MerchantTransaction merchantCreditTransaction=new MerchantTransaction();
		merchantCreditTransaction.setAmount(500.0);
		merchantCreditTransaction.setTransactionDateTime(LocalDateTime.now());				
		merchantCreditTransaction.setInfo
		(AmigoWalletConstants.TRANSACTION_INFO_MONEY_WALLET_TO_WALLET_CREDIT+12121);
		merchantCreditTransaction.setRemarks(AmigoWalletConstants.PAYMENT_TYPE_CREDIT);
		customerToMerchantPaymentDAO.creditMoney(merchantCreditTransaction, 1004);
		Assert.assertTrue(true);
	}


}
