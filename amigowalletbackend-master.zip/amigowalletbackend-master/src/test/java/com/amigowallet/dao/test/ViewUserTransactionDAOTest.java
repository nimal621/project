package com.amigowallet.dao.test;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.amigowallet.dao.RewardPointsDAO;
import com.amigowallet.dao.ViewUserTransactionDAO;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.utility.AmigoWalletConstants;


@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@Rollback(true)
public class ViewUserTransactionDAOTest {
	
	/*
	 * This attribute is used in all the test case methods to invoke the methods
	 * of {@link ViewUserTransactionDAO}
	 * 
	 * The annotation @Autowired helps to get the object from Spring container,
	 * we do not have to explicitly create the object to use it.
	 */

		
		@Autowired
		private ViewUserTransactionDAO viewUserTransactionDAO;

		@Test
		public void getAllTransactionByUserIdValidUserId() {
			List<UserTransaction> list= viewUserTransactionDAO
					.getAllTransactions(12121);
			Assert.assertNotNull(list);
		
		}
		
		
			
		
	
		
		
	}



