package com.amigowallet.testsuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.amigowallet.dao.test.DebitCardDAOTest;
import com.amigowallet.dao.test.ForgotPasswordDAOTest;
import com.amigowallet.dao.test.RegistrationDAOTest;
import com.amigowallet.dao.test.RewardPointsDAOTest;
import com.amigowallet.dao.test.TransferToBankDAOTest;
import com.amigowallet.dao.test.UserLoginDAOTest;
import com.amigowallet.dao.test.UserTransactionDAOTest;
import com.amigowallet.dao.test.ViewUserTransactionDAOTest;
import com.amigowallet.service.test.DebitCardServiceTest;
import com.amigowallet.service.test.ForgotPasswordServiceTest;
import com.amigowallet.service.test.RegistrationServiceTest;
import com.amigowallet.service.test.RewardPointsServiceTest;
import com.amigowallet.service.test.TransferToBankServiceTest;
import com.amigowallet.service.test.UserLoginServiceTest;
import com.amigowallet.service.test.UserTransactionServiceTest;
import com.amigowallet.service.test.ViewUserTransactionServiceTest;
import com.amigowallet.validator.test.RegistrationValidatorTest;
import com.amigowallet.validator.test.UserLoginValidatorTest;

/**
 * this will run all the test cases at a time to include the test
 * cases write all the test class in SuiteClasses

 * @author ETA_JAVA
 *
 */
@RunWith(Suite.class)
/** here we are including all the test cases files which needs to be tested */
@Suite.SuiteClasses({ 
	
	DebitCardDAOTest.class,
	ForgotPasswordDAOTest.class,
	RegistrationDAOTest.class,
	RewardPointsDAOTest.class,
	TransferToBankDAOTest.class,
	UserLoginDAOTest.class,
	UserTransactionDAOTest.class,
	ViewUserTransactionDAOTest.class,
	
	DebitCardServiceTest.class,
	ForgotPasswordServiceTest.class,
	RegistrationServiceTest.class,
	RewardPointsServiceTest.class,
	TransferToBankServiceTest.class,
	UserLoginServiceTest.class,
	UserTransactionServiceTest.class,
	ViewUserTransactionServiceTest.class,
	
	UserLoginValidatorTest.class,
	RegistrationValidatorTest.class
})
public class AmigoWalletTestSuite {

}
