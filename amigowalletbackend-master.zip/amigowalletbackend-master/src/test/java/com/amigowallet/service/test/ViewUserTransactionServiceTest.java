package com.amigowallet.service.test;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;


import com.amigowallet.dao.ViewUserTransactionDAO;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.service.RewardPointsService;
import com.amigowallet.service.ViewUserTransactionService;


@RunWith(SpringRunner.class)
@SpringBootTest


public class ViewUserTransactionServiceTest {
	
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		/**
		 * This attribute is initialized with a mock object as It is annotated with @Mock
		 * Mockito annotation.
		 */
		@MockBean
		private ViewUserTransactionDAO viewUserTransactionDAO;
		
		/*
		  This attribute is used in all the test case methods of
		  {@link ViewUserTransactionServiceTest} to invoke the methods of {@link ViewUserTransactionService}. <br>
		  It is annotated with @InjectMocks Mockito annotation which makes it to
		  use mocked objects.
		 */
		@Autowired
		private ViewUserTransactionService viewUserTransactionService;

		@Test
		public void viewUserTransactionValid() throws Exception
		{
			UserTransaction userTransaction1=new UserTransaction();
			userTransaction1.setUserTransactionId((long) 1212769);
			userTransaction1.setAmount(702.13);
			userTransaction1.setRemarks("C");
			userTransaction1.setInfo("money recieved from chanel@infy.com");
			userTransaction1.setTransactionDateTime(LocalDateTime.now());
			userTransaction1.setPointsEarned(0);
			
			UserTransaction userTransaction2=new UserTransaction();
			userTransaction1.setUserTransactionId((long) 1212768);
			userTransaction1.setAmount(502.13);
			userTransaction1.setRemarks("D");
			userTransaction1.setInfo("money deposited to bank");
			userTransaction1.setTransactionDateTime(LocalDateTime.now());
			userTransaction1.setPointsEarned(0);
			
			List<UserTransaction> userTransactionsList=new ArrayList<>();
			userTransactionsList.add(userTransaction1);
			userTransactionsList.add(userTransaction2);
			
			when(viewUserTransactionDAO.getAllTransactions(anyInt())).thenReturn(userTransactionsList);
			List<UserTransaction> list=viewUserTransactionService.getAllTransactions(12121);
			Assert.assertNotNull(list);
		}
		
		@Test
		public void viewUserTransactionInValid() throws Exception
		{
			UserTransaction userTransaction1=new UserTransaction();
			userTransaction1.setUserTransactionId((long) 1212769);
			userTransaction1.setAmount(702.13);
			userTransaction1.setRemarks("C");
			userTransaction1.setInfo("money recieved from chanel@infy.com");
			userTransaction1.setTransactionDateTime(LocalDateTime.now());
			userTransaction1.setPointsEarned(0);
			
			UserTransaction userTransaction2=new UserTransaction();
			userTransaction1.setUserTransactionId((long) 1212768);
			userTransaction1.setAmount(502.13);
			userTransaction1.setRemarks("D");
			userTransaction1.setInfo("money deposited to bank");
			userTransaction1.setTransactionDateTime(LocalDateTime.now());
			userTransaction1.setPointsEarned(0);
			
			List<UserTransaction> userTransactionsList=new ArrayList<>();
			userTransactionsList.add(userTransaction1);
			userTransactionsList.add(userTransaction2);
			expectedException.expect(Exception.class);
			expectedException.expectMessage("ViewUserTransactionService.NO_TRANSACTION");

			
			when(viewUserTransactionDAO.getAllTransactions(anyInt())).thenReturn(null);
			viewUserTransactionService.getAllTransactions(12);
			
		}
		
		

	}



