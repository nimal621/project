package com.amigowallet.service.test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.amigowallet.dao.TransferToBankDAO;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.service.TransferToBankService;
@RunWith(SpringRunner.class)
@SpringBootTest
public class TransferToBankServiceTest {
	/**
	 * This attribute is initialized with a mock object as It is annotated with @Mock
	 * Mockito annotation.
	 */
	@MockBean
	private TransferToBankDAO transferToBankDAO;
	@Rule
	public ExpectedException ee = ExpectedException.none();
	/**
	 * This attribute is used in all the test case methods of
	 * {@link TransferToBankServiceTest} to invoke the methods of {@link TransferToBankService}. <br>
	 * 
	 * It is annotated with @InjectMocks Mockito annotation which makes it to
	 * use mocked objects.
	 */
	@Autowired
	private TransferToBankService transferToBankService;
	
	@Test
	public void debitFromWalletTest() throws Exception
	{
		UserTransaction userTransaction =new UserTransaction();
		
		when(transferToBankDAO.debitFromWallet(any(UserTransaction.class),anyInt())).thenReturn(userTransaction);
		
		UserTransaction userTransactionFromService=transferToBankService.debitFromWallet(12121, 500.0,"D");
		
		Assert.assertNotNull(userTransactionFromService);
	}
	@Test
	public void creditToWalletTest() throws Exception
	{
		UserTransaction userTransaction =new UserTransaction();
		
		when(transferToBankDAO.creditToWallet(any(UserTransaction.class),anyInt())).thenReturn(userTransaction);
		
		UserTransaction userTransactionFromService=transferToBankService.creditToWallet(12121, 500.0,"C");
		
		Assert.assertNotNull(userTransactionFromService);
	}
	
	
}
