package com.amigowallet.service.test;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.amigowallet.dao.MerchantServiceDAO;
import com.amigowallet.model.Merchant;
import com.amigowallet.model.MerchantTransaction;
import com.amigowallet.model.PaymentType;
import com.amigowallet.model.UserTransaction;
import com.amigowallet.service.MerchantServiceService;
import com.amigowallet.service.MerchantServiceServiceImpl;
import com.amigowallet.utility.AmigoWalletConstants;


@RunWith(MockitoJUnitRunner.class)
public class MerchantServiceServiceTest {
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Mock
	private MerchantServiceDAO merchantServiceDAO;
	
	@InjectMocks
	private MerchantServiceService merchantServiceService = new MerchantServiceServiceImpl();

	@Test
	public void merchantDetailsValid() throws Exception
	{
		when(merchantServiceDAO.merchantList()).thenReturn(new ArrayList<Merchant>());
		List<Merchant>merchantList=merchantServiceService.merchantList();
		Assert.assertNotNull(merchantList);
	}
	
	
	@Test
	public void transferMoneyFromUserToMerchantValid() throws Exception
	{
		Merchant merchant=new Merchant();
		merchant.setEmailId("cescorp@infy.com");
		
		PaymentType paymentType1=new PaymentType();
		paymentType1.setPaymentType(AmigoWalletConstants.PAYMENT_TYPE_DEBIT.charAt(0));
		
		PaymentType paymentType2=new PaymentType();	
		paymentType2.setPaymentType(AmigoWalletConstants.PAYMENT_TYPE_CREDIT.charAt(0));
		
		UserTransaction userTransaction1=new UserTransaction();
		userTransaction1.setAmount(500.0);
		userTransaction1.setPaymentType(paymentType1);
			
		Mockito.when(merchantServiceDAO.deductMoney(Mockito.anyObject(), Mockito.anyInt(), Mockito.anyDouble(), Mockito.anyString())).thenReturn(userTransaction1);
		
		Integer rewardPoints=merchantServiceService.deductMoneyFromWallet(12121, 800.0, "D");
		Assert.assertEquals(rewardPoints.intValue(),80);
	}
	
	@Test
	public void transferMoneyFromUserToMerchantInsufficientBalance() throws Exception
	{
		Merchant merchant=new Merchant();
		merchant.setEmailId("cescorp@infy.com");
		merchant.setMerchantId(1004);
		
		PaymentType paymentType1=new PaymentType();
		paymentType1.setPaymentType(AmigoWalletConstants.PAYMENT_TYPE_DEBIT.charAt(0));
		
		PaymentType paymentType2=new PaymentType();	
		paymentType2.setPaymentType(AmigoWalletConstants.PAYMENT_TYPE_CREDIT.charAt(0));
		
		UserTransaction userTransaction1=new UserTransaction();
		userTransaction1.setAmount(500.0);
		userTransaction1.setPaymentType(paymentType1);
		
		Mockito.when(merchantServiceDAO.deductMoney(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(Exception.class);
		expectedException.expect(Exception.class);
		merchantServiceService.deductMoneyFromWallet(12121, 800.0, AmigoWalletConstants.PAYMENT_TYPE_DEBIT);
	}
	
	@Test
	public void merchantReceivedFromUser() throws Exception
	{		
		MerchantTransaction merchantTransaction=new MerchantTransaction();
		merchantTransaction.setMerchantTransactionId((long) 12121);
		Mockito.when(merchantServiceDAO.creditMoney(Mockito.any(), Mockito.any())).thenReturn(merchantTransaction);
		long expected = merchantServiceService.creditMoney(800.0, 1004,"cescorp@infy.com");
		long actual=12121;
		Assert.assertEquals(expected, actual);
		
	}

	
}
