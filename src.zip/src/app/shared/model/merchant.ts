import { MerchantService } from "src/app/shared/model/merchantservice";

export class Merchant {

    public merchantId: number;
    public emailId: String;
    public name: String;
    public mobileNumber: String;
    public merchantServiceTypes: MerchantService[];

    public successMessage: string;
    public errorMessage: string;
}
