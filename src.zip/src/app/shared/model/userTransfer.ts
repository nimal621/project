export class UserTransfer {
    userId: number;
    amount: string;
}