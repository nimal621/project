import { Component, OnInit } from '@angular/core';
import { User } from '../../shared/model/user';
import { UserTransaction } from '../../shared/model/user-transaction';
import { ViewTransactionsService } from './view-transactions.service';
import { animate, keyframes, style, transition, trigger } from '@angular/animations';
@Component({
  selector: 'app-view-transactions',
  templateUrl: './view-transactions.component.html',
  styleUrls: ['./view-transactions.component.css'],
  animations: [
    trigger('loadAnimation', [
      transition('void => *', [
        animate("1000ms ease-out", keyframes([      // key frame specifies the set of styles which should be applied based on timeline
          style({ opacity: 0, offset: 0 }),         // at 0th (offset * time) milisecond opacity is 0
          style({ opacity: 1, offset: 1 }),         // at 1000th (offset * time) milisecond opacity is 1
        ]))
      ])
    ])
  ]
})
export class ViewTransactionsComponent implements OnInit {
  userId: number;
  password: string;
  transaction: UserTransaction[] = null;
  errorMessage: string = null;
  wTwTransaction: UserTransaction[] = [];
  wTbTransaction: UserTransaction[] = [];
  bTwTransaction: UserTransaction[] = [];
  wtw: boolean = false;
  wtb: boolean = false;
  btw: boolean = false;
  constructor(private viewTransactionsService: ViewTransactionsService) { }
  ngOnInit() {
    let user: User = JSON.parse(sessionStorage.getItem('user'));
    if (user != null) {
      this.userId = user.userId;
      this.password = user.password;
      this.viewTransactionsService.getAllTransactions(this.userId).subscribe(
        (response) => { this.transaction = response },
        (error) => {
          this.errorMessage = error.error.message
        }
      )
    }
  }
  walletToWallet() {
    this.wtw = true;
    this.wtb = false;
    this.btw = false;
    this.wTwTransaction = [];
    for (let t of this.transaction) {
      if (t.paymentType.paymentFrom == 'W' && t.paymentType.paymentTo == 'W') {
        this.wTwTransaction.push(t);
      }
    }
  }
  walletToBank() {
    this.wtw = false;
    this.wtb = true;
    this.btw = false;
    this.wTbTransaction = [];
    for (let t of this.transaction) {
      if (t.paymentType.paymentFrom == 'W' && t.paymentType.paymentTo == 'B') {
        this.wTbTransaction.push(t);
      }
    }
  }
  bankToWallet() {
    this.wtw = false;
    this.wtb = false;
    this.btw = true;
    this.bTwTransaction = [];
    for (let t of this.transaction) {
      if (t.paymentType.paymentFrom == 'B' && t.paymentType.paymentTo == 'W') {
        this.bTwTransaction.push(t);
      }
    }
  }

}
