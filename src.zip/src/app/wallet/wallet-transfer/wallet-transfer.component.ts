import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '../../../../node_modules/@angular/forms';
import { trigger, transition, animate, keyframes, style } from '../../../../node_modules/@angular/animations';
import { AmountValidator } from '../../shared/amount.validator';
import { TransferToWalletService } from './wallet-transfer.service';
import { User } from '../../shared/model/user';
import { ProfileService } from '../../shared/profile.service';
import { TranslateService } from '../../../../node_modules/@ngx-translate/core';
import { THROW_IF_NOT_FOUND } from '../../../../node_modules/@angular/core/src/di/injector';


@Component({
  selector: 'app-wallet-transfer',
  templateUrl: './wallet-transfer.component.html',
  styleUrls: ['./wallet-transfer.component.css'],
  animations:[
    trigger('loadAnimation',[
      transition('void=>*',[
        animate("1000ms ease-out", keyframes([
          style({opacity:0,offset:0}),
          style({opacity:1,offset:1}),
        ]))
      ])
    ])

  ]
})
export class WalletTransferComponent implements OnInit {
  walletCreds:FormGroup
  successMessage: any;
  errorMessage: any;
  receiver: User;
  user: User;
  value: number;

  constructor(private fb:FormBuilder,private pfs:ProfileService,private service:TransferToWalletService,private translateService:TranslateService) { }

  ngOnInit() {
    this.walletCreds=this.fb.group({
      emailId:['',[Validators.required,Validators.email]],
      amount:['',[Validators.required,AmountValidator.min,Validators.pattern("(\\d)*(.[\\d]{0,2})?")]]

    });
  }
  transferMoney(){

    this.successMessage=null;
    this.errorMessage=null;
    this.receiver=null;
    this.user=JSON.parse(sessionStorage.getItem("user"));
    let amount:number=this.walletCreds.get('amount').value;
    let email:string=this.walletCreds.get('emailId').value;
    if(amount<this.pfs.getBalance()){
      this.service.verifyEmail(email).subscribe(
        (response)=>{
          this.receiver=response;
          
          if(this.receiver.emailId==this.user.emailId){
            this.translateService.get("ERROR_MESSAGES.SELF_WALLET_TRANSFER_ERROR").subscribe(value1=>this.errorMessage=value1)

          }
          else{
            this.pfs.setBalance(this.pfs.getBalance()-amount);
            this.service.transferMoneyToWallet(amount,this.user.userId,this.receiver).subscribe(
              (data)=>{
               this.successMessage=data.message; },
                (error)=>{this.errorMessage=error.error.message;}
        
      )
    }
    },(error)=>{this.errorMessage=error.error.message}
    )
  }
  else{
    this.value=amount;
    this.translateService.get("ERROR_MESSAGES.TRANSFER_BANK_LOW_BALANCE",{value:this.pfs.getBalance().toFixed(2)}).subscribe(value1=>this.errorMessage=value1)
  }
}
}
      
    
    
    



