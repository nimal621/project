import { TestBed } from '@angular/core/testing';

import {TransferToWalletService } from './wallet-transfer.service';

describe('WalletTransferService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service:TransferToWalletService = TestBed.get(TransferToWalletService);
    expect(service).toBeTruthy();
  });
});
