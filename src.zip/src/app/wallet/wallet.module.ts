import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';

import { WalletRoutingModule } from './wallet-routing.module';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { LoadMoneyComponent } from './load-money/load-money.component';
import { PointsComponent } from './points/points.component';
import { ProfileComponent } from './profile/profile.component';
import { ErrorComponent } from './error/error.component';
import { ProfileService } from '../shared/profile.service';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NetBankingSuccessComponent } from './load-money/net-banking-success/net-banking-success.component';
import { WalletComponent } from './wallet.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { PaybillComponent } from './paybill/paybill.component';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';


export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

@NgModule({
  imports: [
    CommonModule,
    WalletRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    })
  ],
  declarations: [
    WalletComponent,
    ChangePasswordComponent,
    LoadMoneyComponent,
    PointsComponent,
    ProfileComponent,
    ErrorComponent,
    NetBankingSuccessComponent,
    PaybillComponent,
    ViewTransactionsComponent
  ],
  providers: [ProfileService]
})
export class WalletModule { }
