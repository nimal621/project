import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { UriService } from '../../shared/uri.service';
import { Observable } from '../../../../node_modules/rxjs';
import { AmountValidator } from '../../shared/amount.validator';

@Injectable({
  providedIn: 'root'
})
export class PaybillService {

  paybillUrl: string;
  
  
  constructor(private http: HttpClient, private uriService: UriService) {
    this.paybillUrl = this.uriService.buildAmigoWalletUri();
   }
   paybill(): Observable<any>{
    return this.http.get<any>(this.paybillUrl + '/paybill/merchantList');
   }
   DeductMoney(userId:number,amount:number,type:string): Observable<any>{
    return this.http.post<any>(this.paybillUrl + '/paybill/DeductMoney',[userId,amount,type]);
   }
   CreditMoney(amount:number,merchantId:number,emailId:String):Observable<any>{
    return this.http.post<any>(this.paybillUrl + '/paybill/CreditMoney',[amount,merchantId,emailId]);
   }
}
