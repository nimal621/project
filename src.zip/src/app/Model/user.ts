export class User {
    
    public userid: number;
	public emailid: string;
	public mobileno: string;
    public empname: string;
    public empno: number;
	
	
}