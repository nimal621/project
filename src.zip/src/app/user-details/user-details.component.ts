import { Component, OnInit } from '@angular/core';
import { User } from '../Model/user';
import {UserDetailsService} from './user-details.service'
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  
  user:User[];
  errorMessage:String=null;
  constructor(private userDetailsService:UserDetailsService) { }

  ngOnInit(){
    this.userDetailsService.getAllUserDetails().subscribe(
      (response)=>{this.user=response;},
      (error)=>{this.errorMessage=error.error.Message}
    )
  }

}
