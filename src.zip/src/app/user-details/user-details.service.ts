import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {User} from '../Model/user';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  constructor(private http:HttpClient ) { }

  getAllUserDetails():Observable<User[]>
  {
    return this.http.get<User[]>("http://localhost:3557/FirstBackend/AllUserAPI/AllUser_details")
  }
}
