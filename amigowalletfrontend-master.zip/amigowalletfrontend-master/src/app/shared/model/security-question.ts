export class SecurityQuestion {
    questionId: number;
    question: string;
}