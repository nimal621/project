export class MerchantService {

    public serviceId: number;
    public serviceType: String;
}
