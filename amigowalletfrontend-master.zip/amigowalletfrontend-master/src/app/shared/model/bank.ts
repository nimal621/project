/**
 * This is a model class which has the attributes to keep Bank properties
 */
export class Bank {
    public bankId: number;
    public bankName: string;
}