import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserTransaction } from '../../shared/model/user-transaction';
import { UriService } from '../../shared/uri.service';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ViewTransactionsService {
  amigoWalletUrl: string;
  constructor(private http: HttpClient, private uriService: UriService) {
    this.amigoWalletUrl = this.uriService.buildAmigoWalletUri();
  }
  getAllTransactions(userId: number): Observable<UserTransaction[]> {
    return this.http.get<UserTransaction[]>(this.amigoWalletUrl + '/viewTransactions/' + userId)
  }
}
