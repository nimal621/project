import { Component, OnInit } from '@angular/core';
import { keyframes, trigger, transition, style, animate } from '../../../../node_modules/@angular/animations';
import { FormGroup, FormBuilder, Validators } from '../../../../node_modules/@angular/forms';
import { PaybillService } from './paybill.service';
import { ProfileService } from '../../shared/profile.service';
import { Merchant } from '../../shared/model/merchant';
import { MerchantService } from '../../shared/model/merchantservice';
import { User } from '../../shared/model/user';
import { UserTransaction } from '../../shared/model/user-transaction';


@Component({
  selector: 'app-paybill',
  templateUrl: './paybill.component.html',
  styleUrls: ['./paybill.component.css'],
  animations: [
    trigger('loadAnimation', [
      transition('void => *', [
        animate("1000ms ease-out", keyframes([      // key frame specifies the set of styles which should be applied based on timeline
          style({ opacity: 0, offset: 0 }),         // at 0th (offset * time) milisecond opacity is 0
          style({ opacity: 1, offset: 1 }),         // at 1000th (offset * time) milisecond opacity is 1
        ]))
      ])
    ])
  ]
})
export class PaybillComponent implements OnInit {
  idOfIntervalFunction:any;
  merchantForm:FormGroup;
  successMessage:string;
  errorMessage:string;
  balance:number;
  payAmount:number;
  merchants: Merchant[];
  services: MerchantService[];
  mer;
  points:string;
  mid=this.mer;
  midbe;
  ed;
  constructor(public fb:FormBuilder,public servicePaybill:PaybillService,public serviceProfile:ProfileService) { }

  ngOnInit() {
    this.amountGenerate();
    this.updateBalance();
    this.merchantForm=this.fb.group({merchant:['',Validators.required],
      service:['',Validators.required]})

      this.servicePaybill.paybill().subscribe(
        (response)=>{this.merchants=response;})

     
  }


    

  change1(val:string){
    let i;
    for(i=0;i<this.merchants.length;i++){
      if(this.merchants[i].name==val){
        this.services=this.merchants[i].merchantServiceTypes
        this.mer=this.merchants[i].merchantId;
        this.ed=this.merchants[i].name;
      }
    }
  }
  

pay(){
  this.successMessage=null;
  this.errorMessage=null;
  let user1: User = JSON.parse(sessionStorage.getItem("user"));
  user1.balance = this.serviceProfile.getBalance();
  this.merchantForm.reset();
  let uId=user1.userId;
  let atp=this.payAmount;
  let midf=this.mer;
  let edf=this.ed;
  
  if(user1.balance>atp){
    this.servicePaybill.DeductMoney(uId,atp,edf).subscribe((responseData:any)=>
    {
      this.points=responseData+" points.";
      
      this.successMessage="Transaction is successful and you earned ";

  }
)
this.servicePaybill.CreditMoney(atp,midf,edf).subscribe(
  (response)=>{
    this.midbe=response;
  }
)

this.idOfIntervalFunction = setInterval(()=>{
  let tempUser = new User();
  tempUser.userId = user1.userId;
  this.serviceProfile.getBalanceFromDB(tempUser).subscribe(responseData => {
    let userFromBackEnd:User = responseData;
    this.serviceProfile.setBalance(userFromBackEnd.balance);
    this.serviceProfile.setPoints(userFromBackEnd.rewardPoints);
  })
})
}
  else{
  this.errorMessage="Wallet has insufficient balance for transaction."
  }
}

updateBalance(){
  this.balance=this.serviceProfile.getBalance();
  }

randomInt(min:number,max:number):any{
  return (Math.random()*(max-min+1))+min;
}

amountGenerate(){
  this.payAmount=this.randomInt(50,200);
}
}