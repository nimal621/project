import { Injectable } from "../../../../node_modules/@angular/core";
import { HttpClient } from "../../../../node_modules/@angular/common/http";
import { UriService } from "../../shared/uri.service";
import { Observable } from "../../../../node_modules/rxjs";
import { User } from "../../shared/model/user";
import { UserTransaction } from "../../shared/model/user-transaction";

@Injectable({
    providedIn: 'root'

})
export class TransferToWalletService{
    amigoWalletUrl:string;
    constructor(private http:HttpClient,private uriService:UriService){
        this.amigoWalletUrl=this.uriService.buildAmigoWalletUri();
    }
    verifyEmail(emailId:String):Observable<User>{
        return this.http.post<User>(this.amigoWalletUrl+'/wtwTransfer/getUser',emailId);

    }
    transferMoneyToWallet(amount:number,userId:number,user:User):Observable<UserTransaction>{
        return this.http.post<UserTransaction>(this.amigoWalletUrl+'/wtwTransfer/transferMoney/'+userId+"/"+amount,user);

    
    }
    }
