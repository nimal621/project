import { Component, OnInit } from '@angular/core';
import { animate, keyframes, style, transition, trigger } from '@angular/animations';
import { FormBuilder, Validators,FormGroup} from '@angular/forms';
import { AmountValidator } from '../../shared/amount.validator';
import { LoggerService } from '../../shared/logger.service';
import { TransferService } from './transfer.service';
import { ProfileService } from '../../shared/profile.service';
import { UserTransfer } from '../../shared/model/userTransfer';
import { User } from '../../shared/model/user';
import { TranslateService } from '../../../../node_modules/@ngx-translate/core';
//  This component provides the provision for debiting money from wallet and crediting to bank 


/** Annotation which specifes this as a component 
 * 
 * moduleId: This specified for specifing that the path used in the component are relative to this component
 * templateUrl: This is the relative path for the html related to this component
 * styleUrls: This is the relative path for the css related to this component
 * providers: specifies the service class which communicates with the Serverside application
 *            specifing here makes it available only in this class
 * animations: specifing the animation for the component
*/
@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css'],
  animations: [
    /** trigger the animation when loadAnimation (an attribute in div tag of Html)
     * value has a transition from void to some value(*) ( void when the component is not at loaded,
     * once the component is loaded it will be initialized to active)
     */
    trigger('loadAnimation', [
      transition('void => *', [
        animate("1000ms ease-out", keyframes([      // key frame specifies the set of styles which should be applied based on timeline
          style({ opacity: 0, offset: 0 }),         // at 0th (offset * time) milisecond opacity is 0
          style({ opacity: 1, offset: 1 }),         // at 1000th (offset * time) milisecond opacity is 1
        ]))
      ])
    ])
  ]
})
export class TransferComponent implements OnInit {
  /** class instance variales */
  ifsc:string;
  accountNumber:number;
  accountHolderName:string;
  amount:number;
  successMessage:string;
  errorMessage:string;
  submitted=false;
  ermsg:string;
  value:number;
  smsg:string;
  /**
   * form group for entering account details and verifying details 
   * 
   * Validation of 
   *               ifsc                - ifsc should contain 4 characters and 7 digits
   *               accountNumber       - accountNumber should contain only 15 digits
   *               accountHolderName   - accountHolderName should have alphabets and spaces
   *               amount              - Amount will allow positive numbers (Custom validator {@link AmountValidator})
   *                                  It should be rounded off to two decimal places
   *                
   */
  transferForm = this.fb.group({
    ifsc: ["",[Validators.required, Validators.pattern("[A-Z]{4}[0-9]{7}")]],
    accountNumber: ["", [Validators.required, Validators.pattern("[0-9]{15}")]],
    accountHolderName: ["", [Validators.required, Validators.pattern("[A-Za-z]+([ ][A-Za-z]+)*")]],
    amount: ["", [Validators.required, Validators.pattern("[0-9]+([.][0-9]{1,2})?"), AmountValidator.min]]
  });
  /** constructor will be executed on creation of object creation 
    * 
    * the objects specified as parameters will be injected while execution 
    * and these are used as instance variables 
    */
  constructor(public fb: FormBuilder,  private translateService: TranslateService, private logger: LoggerService,
    private transferService: TransferService,private profileService:ProfileService) { }

  /**
   * Life cycle method on init (overided from OnInit)
   */
  ngOnInit() {

    

  }
  
    /**
   * This method is used for checking entered amount is valid
   * and verifying entered account details and debiting money from wallet
   * and crediting to bank
   */
  transfer(){
    this.submitted=true;
    this.successMessage=null;
    this.errorMessage=null;
    this.ermsg=null;
    this.smsg=null;
    
    if(this.profileService.getBalance()>this.transferForm.controls["amount"].value){
      let user: User = JSON.parse(sessionStorage.getItem("user"));
      let userTransfer: UserTransfer = new UserTransfer();
      userTransfer.amount = this.transferForm.controls["amount"].value;
      userTransfer.userId = user.userId;
      
    this.transferService.accountVerification(this.transferForm.value).subscribe(
      value => {this.successMessage=value;
        this.logger.info(this.successMessage)
        this.transferService.transferToBank(userTransfer).subscribe(
        value => {this.successMessage=value;
          this.logger.info(this.successMessage)
          this.profileService.subMoney(this.transferForm.controls["amount"].value);
          this.transferService.addMoneyToBank(this.transferForm.controls["amount"].value,this.transferForm.value).subscribe(
          value => {this.smsg=value;
          this.submitted=false;
          this.transferForm.reset();
                    this.logger.info(this.smsg)},
          
        error => {
          error.error = JSON.parse(error.error);
          this.transferService.creditWallet(userTransfer).subscribe(
            value=>{this.profileService.addMoney(this.transferForm.controls["amount"].value);
            this.successMessage="money is credited to wallet";
            this.logger.info(this.successMessage)},
            
            error=>{
              this.errorMessage=error.error.message;
              this.logger.error(this.errorMessage, error);
            }
          )
          if (error.error.message != null) {
            this.errorMessage = error.error.message;
          } else {
            this.translateService.get("ERROR_MESSAGES.SERVER_DOWN").subscribe(value => this.errorMessage = value)
              ;
          }
          this.submitted=false;
          this.logger.error(this.errorMessage, error);
        })},
    
      error => {
        error.error = JSON.parse(error.error);
            if (error.error.message != null) {
              this.errorMessage = error.error.message;
            } else {
              this.translateService.get("ERROR_MESSAGES.SERVER_DOWN").subscribe(value => this.errorMessage = value)
                ;
            }
            this.submitted=false;
            this.logger.error(this.errorMessage, error);
          });},
      
    error => {
      
        error.error = JSON.parse(error.error);
          if (error.error.message != null) {
            this.errorMessage = error.error.message;
          } else {
            this.translateService.get("ERROR_MESSAGES.SERVER_DOWN").subscribe(value => this.errorMessage = value)
              ;
          }
          this.submitted=false;
          this.logger.error(this.errorMessage, error);
        });
     
    }
    else{
      this.submitted=false;
      this.ermsg="Insufficient balance";
      this.value=Math.round(this.profileService.getBalance()*100)/100;
      this.logger.info(this.ermsg)
    }
  }
  
  }


