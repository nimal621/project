import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UriService } from '../../shared/uri.service';
/**
 * This is a service class used from transfer component
 *  
 * this communicats with the server side application and does requied work
 *
 * @Injectable A marker metadata which specifies any class which can be 
 * injected can be injected to this class
 */
@Injectable({
  providedIn: 'root'
})
export class TransferService {
 
  /** required url */
amigoWalletUrl: string;
  eduBankUrl: string;

  /** constructor will be executed on creation of object creation 
   * 
   * the objects specified as parameters will be injected while execution 
   * and these are used as instance variables 
   *
   * urls are initialized
   */
  constructor(private http: HttpClient, private uriService: UriService) {
    this.amigoWalletUrl = this.uriService.buildAmigoWalletUri();
    this.eduBankUrl = this.uriService.buildEduBankUri();
  }
  
/**
   * This method calls the debitFromWallet method
   * in TransferToBankAPI of eWallet
   * using an http post request 
   * which returns a ResponseEntity<UserTransaction>
   */
  transferToBank(data:any): Observable<any> {
    return this.http.post(this.amigoWalletUrl + '/TransferToBankAPI/debitFromWallet/', data,{responseType: "text"})
  
  }
  /**
   * This method calls the creditToWallet method
   * in TransferToBankAPI of eWallet
   * using an http post request 
   * which returns a ResponseEntity<UserTransaction>
   */
  creditWallet(data:any): Observable<any> {
    return this.http.post(this.amigoWalletUrl + '/TransferToBankAPI/creditToWallet/', data,{responseType: "text"})
  
  }
  /**
 * This method calls the verifyAccountDetails method
 * in AccountAPI of PaymentServices
 * using an http post request
 * which returns a ResponseEntity<String>
 */
  accountVerification(data:any):Observable<any>{
    return this.http.post(this.eduBankUrl + '/AccountAPI/accountVerification/' , data,{responseType: "text"})

  }
  /**
 * This method calls the creditMoneyToAccount method
 * in AccountAPI of PaymentServices
 * using an http post request
 * which returns a ResponseEntity<String>
 */
  addMoneyToBank(amount:number,data:any):Observable<any>{
    return this.http.post(this.eduBankUrl + '/AccountAPI/creditMoney/'+amount , data,{responseType: "text"})

  }
}
