import { TestBed } from '@angular/core/testing';

import { TransferService } from './transfer.service';
import { UriService } from "../../shared/uri.service";
import { HttpClientModule } from '@angular/common/http';
describe('TransferService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
      providers: [TransferService, UriService]
  }));

  it('should be created', () => {
    const service: TransferService = TestBed.get(TransferService);
    expect(service).toBeTruthy();
  });
});
