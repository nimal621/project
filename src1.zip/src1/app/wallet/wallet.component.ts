import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { User } from "../shared/model/user";
 
/** this component is loaded once the user login, it is layout type of component which 
    holds/loads the component for different functionality */


/** Annotation which specifes this as a component 
 * 
 * moduleId: This specified for specifing that the path used in the component are relative to this component
 * templateUrl: This is the relative path for the html related to this component
 * styleUrls: This is the relative path for the css related to this component
*/
@Component({
  templateUrl: 'wallet.component.html',
  styleUrls: ['wallet.component.css']
})
export class WalletComponent implements OnInit {

  /** class instance variales */
  user: User;
  selectedOption: number;
  backgroundWidth: string;
  backgroundHeight: string;

  /** constructor will be executed on creation of object creation 
   * 
   * the objects specified as parameters will be injected while execution 
   * and these are used as instance variables 
   */
  constructor(private _router: Router, private _route: ActivatedRoute) {}

  /**
   * Life cycle method on init (overided from OnInit)
   */
  ngOnInit() {
    let strUser: string = sessionStorage.getItem("user");
    this.user = JSON.parse(strUser);
  }

  /**
   * This method loads the corresponding outlet on the home page
   * based on the option given in the switch function
   */
  select(option: number) {
    this.selectedOption = option;
    switch (option) {
      case 1: {
        /** navigate to /addMoney relative to the current path i.e. append /home to current path
         */
          this._router.navigate(["addMoney"], {relativeTo: this._route});
        break;
      }
      case 2: {
       /** navigate to /redeem relative to the current path i.e. append /home to current path
         */
          this._router.navigate(["walletTransfer"], {relativeTo: this._route});
        break;
      }
       
      case 3: {
        /** navigate to /paybills relative to the current path
          */
           this._router.navigate(["paybills"], {relativeTo: this._route});
         break;
       }
       case 4: {
        /** navigate to /transfer relative to the current path 
          */
           this._router.navigate(["transfer"], {relativeTo: this._route});
          break;
        }
      case 5:{
        /*** navigate to /viewTransactions */
         this._router.navigate(["viewTransactions"],{relativeTo: this._route});
                      break;
       }
       case 6: {
        /** navigate to /redeem relative to the current path i.e. append /home to current path
          */
        this._router.navigate(["redeem"], {relativeTo: this._route});
       break;
    }
    }

  }
}