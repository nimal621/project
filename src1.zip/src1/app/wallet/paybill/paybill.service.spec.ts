import { TestBed } from '@angular/core/testing';

import { PaybillService } from './paybill.service';

describe('PaybillService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PaybillService = TestBed.get(PaybillService);
    expect(service).toBeTruthy();
  });
});
