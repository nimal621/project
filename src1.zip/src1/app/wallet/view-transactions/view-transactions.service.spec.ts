import { TestBed } from '@angular/core/testing';

import { ViewTransactionsService } from './view-transactions.service';

describe('ViewTransactionsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewTransactionsService = TestBed.get(ViewTransactionsService);
    expect(service).toBeTruthy();
  });
});
