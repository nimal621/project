package com.example.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.entity.UserEntity;
import com.example.model.User;

@Repository(value = "editUserDao")
public class EditUserDAOImpl implements EditUserDAO{

	@Autowired
	EntityManager entityManager;
    
	@Override
	public Integer editUserDetails(User user)
	{   System.out.println("hai");
	    
		UserEntity userEntity = entityManager.find(UserEntity.class, user.getUserid());
//		userEntity.setUserId(user.getUserid());
		if(user.getEmpname()!=null)
		userEntity.setEmpName(user.getEmpname());
		if(user.getMobileno()!=null)
		userEntity.setMobileNo(user.getMobileno());
		if(user.getEmailid()!=null)
		userEntity.setEmailId(user.getEmailid());
		if(user.getEmpno()!=null)
		userEntity.setEmpNo(user.getEmpno());
		System.out.println("hello");
		entityManager.persist(userEntity);
		System.out.println("hi");
		return userEntity.getUserId();
	}
}
