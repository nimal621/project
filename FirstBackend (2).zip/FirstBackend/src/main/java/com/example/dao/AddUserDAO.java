package com.example.dao;

import com.example.model.User;

public interface AddUserDAO {

	public Integer addUserDetails(User user);
}
