package com.example.dao;

import com.example.model.User;

public interface EditUserDAO {

	public Integer editUserDetails(User user);
}
