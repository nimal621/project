package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.entity.UserEntity;
import com.example.model.User;

@Repository(value = "allUserDao")
public class AllUserDAOImpl implements AllUserDAO{

	@Autowired
	EntityManager entityManager;
    
	@Override
	public List<User> allUserDetails()
	{Query query = entityManager.createQuery("SELECT c FROM UserEntity c");
	
	List<UserEntity> userEntity=query.getResultList();
    List<User> user=new ArrayList<>();
	for(UserEntity ue:userEntity)
	{
		User u=new User();
		u.setUserid(ue.getUserId());
		u.setEmpname(ue.getEmpName());
		u.setEmpno(ue.getEmpNo());
		u.setMobileno(ue.getMobileNo());
		u.setEmailid(ue.getEmailId());
		user.add(u);
	}
	
	return user;
	}
}
