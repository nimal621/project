package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

import com.example.dao.AddUserDAO;
import com.example.model.User;

@SpringBootApplication
@PropertySource(value={"classpath:messages.properties"})
public class FirstBackendApplication  {
	@Autowired
	AddUserDAO addUserDao;

	public static void main(String[] args) {
		System.out.println("HI");
		SpringApplication.run(FirstBackendApplication.class, args);
	}
	
//   @Override
//	public void run(String... args)
//	{  System.out.println("HI");
//	   System.out.println("sfss'fk");
//	User user=new User();
//	user.setUserId(1069515);
//	user.setUserName("nimal");
//	user.setEmailID("nimal@gmail.com");
//	user.setMobileNo(9495854203.0);
//	Integer userId=addUserDao.addUserDetails(user);
//	System.out.println(userId);
////		addUser();
//	}
//	
//	public void addUser()
//	{
//		User user=new User();
//		user.setUserId(1069515);
//		user.setUserName("nimal");
//		user.setEmailID("nimal@gmail.com");
//		user.setMobileNo(9495854203.0);
//		Integer userId=addUserDao.addUserDetails(user);
//		System.out.println(userId);
//		
//	}

}
