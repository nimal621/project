package com.example.service;

import com.example.model.User;

public interface DeleteUserService {
	
	public Integer deleteUserDetails(Integer userid) throws Exception;

}
