package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.AddUserDAO;
import com.example.dao.EditUserDAO;
import com.example.model.User;

@Service(value = "EditUserService")
@Transactional
public class EditUserServiceImpl implements EditUserService{

	@Autowired
	private EditUserDAO editUserDao;
	
	@Override
	public Integer editUserDetails(User user) throws Exception
	{   System.out.println("hi");
		Integer userId=editUserDao.editUserDetails(user);
		return userId;
	}
	
}
