package com.example.service;

import com.example.model.User;

public interface AddUserService {
	public Integer addUserDetails(User user) throws Exception;

	

}
