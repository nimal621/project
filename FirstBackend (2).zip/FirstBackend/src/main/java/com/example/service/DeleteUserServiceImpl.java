package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.AddUserDAO;
import com.example.dao.DeleteUserDAO;
import com.example.model.User;

@Service(value = "DeleteUserService")
@Transactional
public class DeleteUserServiceImpl implements DeleteUserService {
	
	@Autowired
	private DeleteUserDAO deleteUserDao;
	
    @Override
	public Integer deleteUserDetails(Integer userid) throws Exception
	{   System.out.println("hi");
		Integer userId=deleteUserDao.deleteUserDetails(userid);
		return userId;
	}

}
