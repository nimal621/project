package com.example.service;

import java.util.List;

import com.example.model.User;

public interface AllUserService {

	public List<User> allUserDetails() throws Exception;
}
