package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.AddUserDAO;
import com.example.dao.AllUserDAO;
import com.example.model.User;

@Service(value = "AllUserService")
@Transactional
public class AllUserServiceImpl implements AllUserService {
	
	@Autowired
	private AllUserDAO allUserDao;
	
	@Override
	public List<User> allUserDetails() throws Exception
	{   System.out.println("hi");
		List<User> u=allUserDao.allUserDetails();
		return u;
	}

}
