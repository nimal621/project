package com.example.service;

import com.example.model.User;

public interface EditUserService {

	public Integer editUserDetails(User user) throws Exception;
}
