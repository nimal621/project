package com.example.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.model.User;
import com.example.service.AddUserService;
import com.example.service.DeleteUserService;

@CrossOrigin
@RestController
@RequestMapping("DeleteUserAPI")
public class DeleteUserAPI {
	
	@Autowired
	private Environment environment;
	
	@Autowired
	DeleteUserService deleteUserService;
	
	@RequestMapping(value="Delete_user/{userid}",method=RequestMethod.GET)
	public ResponseEntity<String> deleteUserDetails(@PathVariable("userid") Integer userid)
	{   System.out.println("hi");
		ResponseEntity<String> responseEntity=null;
		String message=null;
		try { System.out.println("hi");
			 Integer userId=deleteUserService.deleteUserDetails(userid);
			 message = environment.getProperty("DeleteUserAPI.SUCCESSFUL_DELETED")+userId;
			 responseEntity=new ResponseEntity<String>(message, HttpStatus.OK);
			 System.out.println("hi");
		}
		catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.CONFLICT, environment.getProperty(e.getMessage()));
		}
		return responseEntity;
	}
	

}
