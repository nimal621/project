package com.example.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.model.User;
import com.example.service.AddUserService;
import com.example.service.AllUserService;

@CrossOrigin
@RestController
@RequestMapping("AllUserAPI")
public class AllUserAPI {
	
	@Autowired
	private Environment environment;
	
	@Autowired
	AllUserService allUserService;
	
	@RequestMapping(value="AllUser_details",method=RequestMethod.GET)
	public ResponseEntity<List<User>> allUserDetails()
	{   System.out.println("hi");
		ResponseEntity<List<User>> responseEntity=null;
//		String message=null;
		try { System.out.println("hi");
			 List<User> u=allUserService.allUserDetails();
//			 message = environment.getProperty("AddUserAPI.SUCCESSFUL_ADDED")+userId;
			 responseEntity=new ResponseEntity<List<User>>(u, HttpStatus.CREATED);
			 
		}
		catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.CONFLICT, environment.getProperty(e.getMessage()));
		}
		return responseEntity;
	}

}
