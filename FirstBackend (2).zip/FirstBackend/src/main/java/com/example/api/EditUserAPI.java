package com.example.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.model.User;
import com.example.service.AddUserService;
import com.example.service.EditUserService;

@CrossOrigin
@RestController
@RequestMapping("EditUserAPI")
public class EditUserAPI {

	@Autowired
	private Environment environment;
	
	@Autowired
	EditUserService editUserService;
	
	@RequestMapping(value="user_details",method=RequestMethod.POST)
	public ResponseEntity<String> editUserDetails(@RequestBody User user)
	{   System.out.println("hi");
		ResponseEntity<String> responseEntity=null;
		String message=null;
		try { System.out.println("hi");
			 Integer userId=editUserService.editUserDetails(user);
			 message = environment.getProperty("EditUserAPI.SUCCESSFUL_ADDED")+userId;
			 responseEntity=new ResponseEntity<String>(message, HttpStatus.CREATED);
			 System.out.println("hi");
		}
		catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.CONFLICT, environment.getProperty(e.getMessage()));
		}
		return responseEntity;
	}
	
}
